console.log("loading script.js ...");
var defaultSortOrder = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]; //17 is footer for now so the last
var config = localStorage.getItem("config") == null ? { "lang": "en", "sortorder": defaultSortOrder} : JSON.parse(localStorage.getItem("config"));
if(localStorage.getItem("config") == null)
{
  localStorage.setItem("config", JSON.stringify(config));
}
function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
}

window.SubmitForm = (id) => {
    document.getElementById(id).submit();
};

/* graphs (checked) */
window.ToggleBitrateGraph = function() {
  const checkbox = document.getElementById('bitrateSwitch');
  if (checkbox) {
    document.getElementById('bitrateChart').classList.toggle('force-show', checkbox.checked);
  }
};

function updateSortOrder() {
  config.sortorder = [...document.querySelectorAll('[data-sort]')].map(element => element.getAttribute('data-sort'));
  localStorage.setItem('config', JSON.stringify(config));
}

document.addEventListener('click', function(e) {
  if (!e.target.matches('button.sortprev, button.sortnext')) return;

  const parentDiv = e.target.closest('div');
  const currentVal = parentDiv.getAttribute('data-sort');
  const currentElement = document.querySelector(`[data-sort='${currentVal}']`);
  
  // Find the next/previous element with data-sort (skip any gaps)
  let targetElement = e.target.matches('.sortprev') 
    ? currentElement.previousElementSibling
    : currentElement.nextElementSibling;
  
  // Keep looking until we find an element with data-sort
  while (targetElement && !targetElement.hasAttribute('data-sort')) {
    targetElement = e.target.matches('.sortprev')
      ? targetElement.previousElementSibling
      : targetElement.nextElementSibling;
  }

  if (targetElement?.hasAttribute('data-sort')) {
    // Move elements
    if (e.target.matches('.sortprev')) {
      // Move up: insert current before target
      currentElement.parentNode.insertBefore(currentElement, targetElement);
    } else {
      // Move down: insert target before current
      currentElement.parentNode.insertBefore(targetElement, currentElement);
    }
    
    updateSortOrder();
  }
});
window.SortButtonsClick = function() {
  document.querySelectorAll('button.sortprev, button.sortnext').forEach(button => {
    button.classList.toggle('force-show');
  });
};
document.addEventListener("click", function(e) {
  if (e.target.matches("#resetelements")) {
    let configItem = localStorage.getItem("config");
    let configString = JSON.parse(configItem);
    configString.sortorder = defaultSortOrder;
    localStorage.setItem("config", JSON.stringify(configString));
    
    location.reload();
  }
});
let prev_modems;
let prev_temps;
let update_timer;
let isElgatoActive = false;
let isPreviousElgatoActive = false;
let isStandaloneGraph = false;
let wifiArray = [];
let configData = null;


if (window.location.hash.substring(1) == "connectionsummary") {
    document.getElementById('content').style.display = 'none';
    let summary = document.getElementById('connectionsummary');
    summary.remove();
    const table = document.createElement('table');
    const tbody = document.createElement('tbody');
    tbody.appendChild(summary);
    table.appendChild(tbody);
    document.body.appendChild(table);
}
if (window.location.hash.substring(1) == "graph-bitrate") {
    document.getElementById('content').style.display = 'none';
    let chart = document.getElementById('bitrateChart');
    chart.remove();
    document.body.appendChild(chart);
    isStandaloneGraph = true;
}
if (window.location.hash.substring(1) == "webrtc") {
    document.getElementById('iframecollapsebutton').click();
    document.getElementById('content').style.display = 'none';
    let webrtc = document.getElementById('webrtcvideoiframe');
    webrtc.remove();
    document.body.appendChild(webrtc);
}

//#region Modems
window.SetCurrentOperatorCode = (modemId, operatorCodeString) => {
    // let wifiDeviceName = document.querySelector(selector).getAttribute('data-wifidevicename');
    let element = document.querySelector(`#operatorcode-${modemId} input`);
    element.value = operatorCodeString;
};
//#endregion

// This is getting used by dynamic created javascript
document.addEventListener('click', function(event) {
    if (event.target.matches('.hotspotssiditem')) {
        let ifacename = event.target.getAttribute('data-ifacename'); // luckily this is now macaddress regardless the name data-ifacename
        
        // Set the value and trigger input
        let ssidInput = document.querySelector(`#block-${ifacename} .ssidname`);
        if (ssidInput) {
            ssidInput.value = event.target.textContent;
            
            // THIS IS VERY IMPORTANT FOR ALL FORM CHANGES TO TRIGGER IN BLAZOR - I HAVE TO USE REAL DOM.
            ssidInput.dispatchEvent(new Event('input', { bubbles: true }));
            ssidInput.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }
    /*
    if (event.target.matches('.dropdown-item')) {
        event.preventDefault();
    }*/
});

document.addEventListener('click', function(event) {
    if (event.target.matches('.hotspotbutton')) {
        let ifacename = event.target.getAttribute('data-ifacename');
        
        if (!event.target.classList.contains("clicked")) {
            /* spinning loading */
            let hotspotbutton = event.target;
            hotspotbutton.innerHTML = '';
            hotspotbutton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Retrieving Hotspots';

            hotspotbutton.classList.add(`clicked`, `active`, ifacename);
            
            fetch(`/api/ui/gethotspots?wifiInterfaceName=${ifacename}`)
                .then(response => response.json())
                .then(data => {
                    let returnString = "";
                    data.Hotspots.forEach((item, index) => {
                        returnString += `${item.Bars} <a class="hotspotssiditem" data-ifacename="${ifacename}" onclick="return false;" href="#">${item.Ssid}</a><br/>`;
                    });
                    
                    // Initialize Bootstrap popover
                    const popoverElement = document.querySelector(`.hotspotbutton.clicked.${ifacename}`);
                    if (popoverElement && typeof bootstrap !== 'undefined') {
                        const popover = new bootstrap.Popover(popoverElement, {
                            html: true,
                            content: returnString,
                            sanitize: false,
                            container: 'body',
                            placement: "top"
                        });
                        popover.show();
                        
                        // Style the popover
                        const popoverInstance = bootstrap.Popover.getInstance(popoverElement);
                        const popoverElement = document.querySelector('.popover');
                        if (popoverElement) {
                            popoverElement.style.maxWidth = "100%";
                        }
                    }

                    /* remove spinning */
                    hotspotbutton.innerHTML = '';
                    hotspotbutton.textContent = "Hotspots";
                })
                .catch(error => {
                    console.error('Error fetching hotspots:', error);
                    // Clean up on error too
                    hotspotbutton.innerHTML = '';
                    hotspotbutton.textContent = "Hotspots";
                    hotspotbutton.classList.remove(`clicked`, `active`, ifacename);
                });
        } else {
            // Hide popover and remove classes
            const popoverElement = document.querySelector(`.hotspotbutton.clicked.${ifacename}`);
            if (popoverElement && typeof bootstrap !== 'undefined') {
                const popover = bootstrap.Popover.getInstance(popoverElement);
                if (popover) {
                    popover.hide();
                }
            }
            event.target.classList.remove(`clicked`, `active`, ifacename);
        }
    }
});

window.SetWifiSsid = (selector) => {
    // let wifiDeviceName = document.querySelector(selector).getAttribute('data-wifidevicename');
    let element = document.querySelector(selector);
    let wifiMacAddr = element.getAttribute('data-wifimacaddr');
    let ssid = element.getAttribute('data-ssid');
    
    if(typeof wifiMacAddr === "undefined" || typeof ssid === "undefined") {
        console.log(ssid);
        console.log(wifiMacAddr);
        alert("Missing devicename or ssid! Please report this as a Bug!");
        return;
    }
    
    var wifiSsidInput = document.querySelector(`#wifiDevice-${wifiMacAddr} input`);
    var wifiConnectButton = document.querySelector(`#wificonnect-${wifiMacAddr}`);
    
    if(wifiSsidInput == null || wifiConnectButton == null) {
        alert("Something went wrong trying to identify the ssid - please refresh the page and retry!");
        return;
    }
    
    wifiSsidInput.value = ssid;
    var event = new Event('change');
    wifiSsidInput.dispatchEvent(event);
    wifiConnectButton.dispatchEvent(event);
};

window.SpinnerLoadingAnimation = (selector, loadingText, deactivateElement = false) => {
    let element = document.querySelector(selector);
    if(element)
    {
        if (!element.classList.contains("clicked")) {
            /* spinning loading */
            element.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>${loadingText}`;
            if (deactivateElement) {
                element.disabled = true;
            }
        }
    }
};
window.SpinnerUnLoadingAnimation = (selector, originalText, deactivateElement = false) => {
    /* remove spinning */
    let element = document.querySelector(selector);
    if(element)
    {
        element.textContent = originalText;
        if (deactivateElement) {
            element.disabled = false;
        }
    }
};
//#region Bonding and Displayname
// Bonding and Network Adapter Display Name
// First method - handles device name click (call from Razor @onclick)
window.ShowDeviceNameEditor = async function (element) {
    if (!element.classList.contains("clicked")) {
        element.classList.add("clicked");
        
        const htmlcontent = element.getAttribute('data-content');
        const macid = element.getAttribute('data-macid');
        const isBonding = element.getAttribute('data-isbonding');
        const canChangeBonding = element.getAttribute('data-canchangebonding');
        
        let checkedString = "";
        if (isBonding === "true") {
            checkedString = " checked";
        }
        
        let overlaycontent = `<p><strong>${htmlcontent}</strong><br/>New Device Name: <input type="text" value="${element.innerHTML}" id="newdevicename" data-macid="${macid}" data-devicename="${htmlcontent}" data-isbonding="${isBonding}" /><br/>Bonding: <input id="isbondingfordevice" class="form-check-input" type="checkbox" value="${isBonding}"${checkedString}></p><button onclick="window.SaveDeviceName()" type="button" class="btn btn-primary btn-sm">save</button>`;
        
        if (canChangeBonding === "false") {
            overlaycontent = `<p><strong>${htmlcontent}</strong><br/>New Device Name: <input type="text" value="${element.innerHTML}" id="newdevicename" data-macid="${macid}" data-devicename="${htmlcontent}" data-isbonding="${isBonding}" /><br/>Bonding: <input id="isbondingfordevice" class="form-check-input" type="checkbox" value="${isBonding}"${checkedString} disabled></p><button onclick="window.SaveDeviceName()" type="button" class="btn btn-primary btn-sm">save</button>`;
        }
        
        // Use Bootstrap popover
        if (typeof bootstrap !== 'undefined') {
            const popover = new bootstrap.Popover(element, {
                html: true,
                content: overlaycontent,
                sanitize: false,
                container: '#section-network',
                placement: "bottom"
            });
            popover.show();
            
            // Style the popover
            const popoverElement = document.querySelector('.popover');
            if (popoverElement) {
                popoverElement.style.maxWidth = "100%";
            }
        }
        
    } else {
        element.classList.remove("clicked");
        if (typeof bootstrap !== 'undefined') {
            const popover = bootstrap.Popover.getInstance(element);
            if (popover) {
                popover.dispose();
            }
        }
    }
};

// Second method - handles save button click (depends on first method)
window.ShowDeviceNameEditor = async function (element) {
    if (!element.classList.contains("clicked")) {
        element.classList.add("clicked");
        
        const htmlcontent = element.getAttribute('data-content');
        const macid = element.getAttribute('data-macid');
        const isBonding = element.getAttribute('data-isbonding');
        const priority = element.getAttribute('data-priority');
        const canChangeBonding = element.getAttribute('data-canchangebonding');
        
        let checkedString = "";
        if (isBonding === "true") {
            checkedString = " checked";
        }
        
        // Build dropdown options 1-10 with pre-selection based on priority attribute
        let dropdownOptions = '';
        const savedPriority = priority || "10"; // Default to "10" if no priority attribute exists
        for (let i = 1; i <= 10; i++) {
            const selected = (i.toString() === savedPriority) ? ' selected' : '';
            dropdownOptions += `<option value="${i}"${selected}>${i}</option>`;
        }
        
        // Base popover content with dropdown
        let overlaycontent = `<p>
            <strong>${htmlcontent}</strong><br/>
            New Device Name: <input type="text" value="${element.innerHTML}" id="newdevicename" data-macid="${macid}" data-devicename="${htmlcontent}" data-isbonding="${isBonding}" /><br/>
            Bonding: <input id="isbondingfordevice" class="form-check-input" type="checkbox" value="${isBonding}"${checkedString}><br/>
            Priority: <select id="prioritydropdown">${dropdownOptions}</select>
        </p>
        <button onclick="window.SaveDeviceName()" type="button" class="btn btn-primary btn-sm">save</button>`;
        
        if (canChangeBonding === "false") {
            overlaycontent = `<p>
                <strong>${htmlcontent}</strong><br/>
                New Device Name: <input type="text" value="${element.innerHTML}" id="newdevicename" data-macid="${macid}" data-devicename="${htmlcontent}" data-isbonding="${isBonding}" /><br/>
                Bonding: <input id="isbondingfordevice" class="form-check-input" type="checkbox" value="${isBonding}"${checkedString} disabled><br/>
                Priority: <select id="prioritydropdown">${dropdownOptions}</select>
            </p>
            <button onclick="window.SaveDeviceName()" type="button" class="btn btn-primary btn-sm">save</button>`;
        }
        
        // Use Bootstrap popover
        if (typeof bootstrap !== 'undefined') {
            const popover = new bootstrap.Popover(element, {
                html: true,
                content: overlaycontent,
                sanitize: false,
                container: '#section-network',
                placement: "bottom"
            });
            popover.show();
            
            const popoverElement = document.querySelector('.popover');
            if (popoverElement) {
                popoverElement.style.maxWidth = "100%";
            }
        }
        
    } else {
        element.classList.remove("clicked");
        if (typeof bootstrap !== 'undefined') {
            const popover = bootstrap.Popover.getInstance(element);
            if (popover) {
                popover.dispose();
            }
        }
    }
};

// Second method - handles save button click
window.SaveDeviceName = async function () {
    const nameInput = document.getElementById('newdevicename');
    const bondingCheckbox = document.getElementById('isbondingfordevice');
    const prioritySelect = document.getElementById('prioritydropdown');  // ADDED: get dropdown
    
    if (nameInput && (nameInput.dataset.macid !== "" || nameInput.dataset.devicename !== "")) {
        const devName = nameInput.dataset.devicename;
        const macid = nameInput.dataset.macid;
        const isBonding = bondingCheckbox ? bondingCheckbox.checked : false;
        const devDisplayName = nameInput.value;
        const selectedPriority = prioritySelect ? prioritySelect.value : "10";  // ADDED: get selected value, default 10
        
        console.log(`macid: ${macid} | devname: ${devName} | DisplayName: ${devDisplayName} | isbonding: ${isBonding} | priority: ${selectedPriority}`);
        
        const configData = {
            Name: devName,
            DisplayName: devDisplayName,
            MacId: macid,
            IsBonding: isBonding,
            Priority: parseInt(selectedPriority, 10)  // ADDED: send selected number as integer
        };
        
        try {
            const response = await fetch(`/api/ui/adddevicedisplayname`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                },
                body: JSON.stringify(configData)
            });
            
            if (response.ok) {
                // Close the popover (unchanged)
                const clickedElement = document.querySelector('.newdevicename.clicked');
                if (clickedElement) {
                    if (typeof bootstrap !== 'undefined') {
                        const popover = bootstrap.Popover.getInstance(clickedElement);
                        if (popover) {
                            popover.dispose();
                        }
                    }
                    clickedElement.classList.remove("clicked");
                }
            } else {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
        } catch (error) {
            console.error("Error saving device name:", error);
            
            // Cleanup on error (unchanged)
            const clickedElement = document.querySelector('.newdevicename.clicked');
            if (clickedElement) {
                if (typeof bootstrap !== 'undefined') {
                    const popover = bootstrap.Popover.getInstance(clickedElement);
                    if (popover) {
                        popover.dispose();
                    }
                }
                clickedElement.classList.remove("clicked");
            }
            alert("New device Name has not been set, because of some error!");
        }
    }
};
//#endregion
document.addEventListener('click', function(event) {
    if (event.target.matches('.popoveritem')) {
        if (!event.target.classList.contains("clicked")) {
            event.target.classList.toggle("clicked");
            
            if (typeof bootstrap !== 'undefined') {
                const popover = new bootstrap.Popover(event.target, {
                    html: true,
                    content: event.target.getAttribute('data-content'),
                    sanitize: false,
                    container: 'body',
                    placement: "top"
                });
                popover.show();
                
                // Style the popover
                const popoverElement = document.querySelector('.popover');
                if (popoverElement) {
                    popoverElement.style.maxWidth = "100%";
                }
            }
        } else {
            event.target.classList.toggle("clicked");
            if (typeof bootstrap !== 'undefined') {
                const popover = bootstrap.Popover.getInstance(event.target);
                if (popover) {
                    popover.hide();
                }
            }
        }
    }
});

document.addEventListener("click", function(e) {
  if (e.target.matches("#refreshBtn")) {
    location.reload();
  }
});

document.addEventListener('close.bs.alert', function(e) {
    if (e.target.matches('.alert')) {
        e.target.style.transition = 'opacity 300ms';
        e.target.style.opacity = '0';
        setTimeout(() => {
            e.target.style.display = 'none';
        }, 300);
        e.preventDefault();
        e.stopPropagation();
    }
});

// Remove existing and add new event listener
const exportConfigBtn = document.getElementById('exportconfig');
if (exportConfigBtn) {
    exportConfigBtn.replaceWith(exportConfigBtn.cloneNode(true)); // Clean way to remove all event listeners
    
    document.getElementById('exportconfig').addEventListener('click', async function(e) {
        e.preventDefault(); // Prevent default behavior
        e.stopPropagation(); // Stop event bubbling
        await downloadFile("/api/ui/getconfig", "config.json");
    });
}
// Remove existing and add new event listener
document.addEventListener('click', async function(e) {
  if (e.target.matches('#exportconfigprofiles')) {
    e.preventDefault();
    e.stopPropagation();
    await downloadFile('/api/ui/getconfigprofiles', 'configProfiles.zip');
  }
});

async function downloadFile(url, filename) {
	try {
		const response = await fetch(url);
		const blob = await response.blob();
		const downloadLink = document.createElement('a');
		downloadLink.href = URL.createObjectURL(blob);
		downloadLink.download = filename;
		document.body.appendChild(downloadLink);
		downloadLink.click();
		setTimeout(() => {
		  URL.revokeObjectURL(downloadLink.href);
		  document.body.removeChild(downloadLink);
		}, 100);
	} catch (error) {
    console.error('Error downloading the file:', error.message);
  }
}

document.addEventListener('click', async function(e) {
    if (e.target.matches('#importconfigprofiles')) {
        const fileInput = document.getElementById('importconfigprofilesfile');
        if (!fileInput.files.length) {
            alert('Please select a ZIP file first');
            return;
        }

        const file = fileInput.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('configZip', file);

        try {
            const response = await fetch('/api/ui/importconfigprofiles', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`[${response.status}: ${response.statusText}] ${await response.text()}`);
            }

            const result = await response.json();
            console.log('Success:', result);
            alert('Upload successful!');
            return result;
        } catch (error) {
            console.error('Error uploading file:', error);
            alert(`Upload failed: ${error.message}`);
            throw error;
        }
    }
});

document.addEventListener('click', async function(e) {
    if (e.target.matches('#importconfig')) {
        const fileInput = document.getElementById('importconfigfile');
        if (!fileInput.files.length) {
            alert('Please select the config.json file first');
            return;
        }

        const file = fileInput.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('configFile', file);

        try {
            const response = await fetch('/api/ui/importconfig', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`[${response.status}: ${response.statusText}] ${await response.text()}`);
            }

            const result = await response.json();
            console.log('Success:', result);
            alert('Upload successful!');
            return result;
        } catch (error) {
            console.error('Error uploading file:', error);
            alert(`Upload failed: ${error.message}`);
            throw error;
        }
    }
});

document.addEventListener("change", function(e) {
    if (e.target.matches("#select-themes")) {
        let themename = e.target.options[e.target.selectedIndex].value;
        if (typeof themename === "undefined") {
            themename = "default";
        }

        const themeLink = document.getElementById("bootstrap-theme");
        if (themename == "default") {
            themeLink.setAttribute("href", `/ui/bootstrap.min.css?t=${Date.now()}`);
        } else {
            themeLink.setAttribute("href", `themes/${themename}/bootstrap.min.css?t=${Date.now()}`);
        }
    }
});

window.show_overlay = (title, text) => {
    const modalTitle = document.getElementById('centeredModalLongTitle');
    const modalBody = document.querySelector('#centeredModal .modal-body');
    
    if (modalTitle) modalTitle.textContent = title;
    if (modalBody) modalBody.textContent = text;
    
    // Bootstrap 5 modal
    if (typeof bootstrap !== 'undefined') {
        const modal = new bootstrap.Modal(document.getElementById('centeredModal'));
        modal.show();
    }
};

//TODO make more generic and reuse. can be done
window.ToggleAPInfos = (buttonId) => {
    const button = document.getElementById(buttonId);
    if (!button) return;
    
    if (!button.classList.contains("clicked")) {
        button.classList.toggle("clicked");
        let ifacename = button.getAttribute('data-ifacename');
        console.log(ifacename);
        
        if (typeof bootstrap !== 'undefined') {
            const popover = new bootstrap.Popover(button, {
                html: true,
                content: button.getAttribute('data-content'),
                sanitize: false,
                placement: "top"
            });
            popover.show();
            
            // Style the popover
            const popoverElement = document.querySelector('.popover');
            if (popoverElement) {
                popoverElement.style.maxWidth = "100%";
            }
        }
    } else {
        button.classList.toggle("clicked");
        if (typeof bootstrap !== 'undefined') {
            const popover = bootstrap.Popover.getInstance(button);
            if (popover) {
                popover.hide();
            }
        }
    }
};
window.TogglePasswordFieldVisibility = (buttonId) => {
    let button = document.getElementById(buttonId);
    let input = button.parentElement.querySelector("input");
    let icon = button.parentElement.querySelector("i");
    
    if (input.type === "text") {
        input.type = "password";
        icon.classList.add("fa-eye-slash");
        icon.classList.remove("fa-eye");
    } else if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    }
};

window.CheckVisibilityById = (elementId) => {
  console.log(`${document.getElementById(elementId).checkVisibility()}`);
  return document.getElementById(elementId).checkVisibility();
};
window.SetWebRtcUrl = (elementId) => {
  //document.getElementById(elementId).setAttribute('src', `http://${window.location.hostname}:8889/moostream`);
  const iframe = document.getElementById(elementId);
  if (iframe.hasAttribute("src"))
  {
    iframe.removeAttribute("src");
    console.log("Iframe disabled");
  }
  else
  {
    iframe.src = iframe.getAttribute("data-webrtcsrc");
    console.log(`setting ${elementId} to ${iframe.src}`)
  }
  //console.log(`setting ${elementId} to http://${window.location.hostname}:8889/moostream`)
};
//#region Videos - PIP
window.updateCSSVariables = async (newVirtualWidth, newVirtualHeight, newScaleFactor, newDraggable = [], initialPositions = [], isTest = false, componentName = "") => {
    // Wait for draggables with timeout
    const waitForElement = (selector, timeout = 5000) => {
        return new Promise((resolve) => {
            const startTime = Date.now();
            
            const check = () => {
                const elements = document.querySelectorAll(selector);
                if (elements.length > 0) {
                    resolve(elements);
                } else if (Date.now() - startTime > timeout) {
                    resolve(null);
                } else {
                    setTimeout(check, 500);
                }
            };
            
            check();
        });
    };
    
    const draggables = await waitForElement('.draggable');
    
    if (!draggables) {
        console.warn('Draggable elements not found after waiting');
        return;
    }
  const container = document.getElementById('videopipfreestylecontainer-'+componentName);
  const snapToggle = document.getElementById('snap-toggle-'+componentName);

  // Update CSS variables
  container.style.setProperty('--virtual-width', newVirtualWidth);
  container.style.setProperty('--virtual-height', newVirtualHeight);
  container.style.setProperty('--scale-factor', newScaleFactor);

  // Set the scale factor and virtual dimensions
  const scaleFactor = newScaleFactor;
  const virtualWidth = newVirtualWidth;
  const virtualHeight = newVirtualHeight;

  // Snap threshold (in virtual coordinates)
  const snapThreshold = 10 / scaleFactor;

  // Initialize draggable positions and sizes
  draggables.forEach((draggable, index) => {
    let devName = draggable.getAttribute("data-deviceName");
    let devPath = draggable.getAttribute("data-devicePath");
    if(isTest)
    {
        draggable.innerHTML = `<span class="verysmalltextnormalview">${index}<br/>Dummy<br/>${newDraggable[index].Width}x${newDraggable[index].Height}</span>`;
    }
    else
    {
        draggable.innerHTML = `<span class="verysmalltextnormalview">${index}<br/>${devName}<br/>${devPath}</span>`;
    }
    // Update draggable size
    draggable.style.width = newDraggable[index].Width * scaleFactor + 'px';
    draggable.style.height = newDraggable[index].Height * scaleFactor + 'px';

    // Set initial positions if provided
    if (initialPositions[index] !== undefined) {
      let xPos = Math.max(0, Math.min(initialPositions[index].XPos, virtualWidth - (newDraggable[index].Width)));
      let yPos = Math.max(0, Math.min(initialPositions[index].YPos, virtualHeight - (newDraggable[index].Height)));
      draggable.style.left = xPos * scaleFactor + 'px';
      draggable.style.top = yPos * scaleFactor + 'px';
    }

    let startX = 0, startY = 0, dragableXPosition = 0, dragableYPosition = 0;

    draggable.addEventListener('mousedown', startDrag);
    draggable.addEventListener('touchstart', startDrag, { passive: false });

    function startDrag(e) {
      e.preventDefault();
      const rect = container.getBoundingClientRect();
      const draggableRect = draggable.getBoundingClientRect();

      // Calculate initial touch position relative to the container
      if (e.type === 'mousedown') {
        startX = e.clientX - (draggableRect.left - rect.left);
        startY = e.clientY - (draggableRect.top - rect.top);

        document.addEventListener('mousemove', drag);
        document.addEventListener('mouseup', stopDrag);
      } else if (e.type === 'touchstart') {
        startX = e.touches[0].clientX - (draggableRect.left - rect.left);
        startY = e.touches[0].clientY - (draggableRect.top - rect.top);

        document.addEventListener('touchmove', drag, { passive: false });
        document.addEventListener('touchend', stopDrag);
      }
    }

    function drag(e) {
      let clientX, clientY;

      if (e.type === 'mousemove') {
        clientX = e.clientX;
        clientY = e.clientY;
      } else if (e.type === 'touchmove') {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      }

      // Calculate virtual coordinates, considering scale factor
      let x = (clientX - startX) / scaleFactor;
      let y = (clientY - startY) / scaleFactor;

      // Debugging logs for touch positions
      console.log(`Touch X: ${clientX}, Touch Y: ${clientY}, Start X: ${startX}, Start Y: ${startY}`);
      console.log(`Calculated virtual X: ${x}, Y: ${y}`);

      if (snapToggle.checked) {
        // Snap to container edges
        if (x < snapThreshold) x = 0;
        if (y < snapThreshold) y = 0;
        if (x > virtualWidth - (draggable.clientWidth / scaleFactor) - snapThreshold)
          x = virtualWidth - (draggable.clientWidth / scaleFactor);
        if (y > virtualHeight - (draggable.clientHeight / scaleFactor) - snapThreshold)
          y = virtualHeight - (draggable.clientHeight / scaleFactor);

        // Snap to other draggable elements
        draggables.forEach((other) => {
          if (other !== draggable) {
            const otherRect = other.getBoundingClientRect();
            const otherX = (otherRect.left - container.getBoundingClientRect().left) / scaleFactor;
            const otherY = (otherRect.top - container.getBoundingClientRect().top) / scaleFactor;
            const otherWidth = other.clientWidth / scaleFactor;
            const otherHeight = other.clientHeight / scaleFactor;

            // Snap to left or right of the other object
            if (Math.abs(x - (otherX + otherWidth)) < snapThreshold) x = otherX + otherWidth;
            if (Math.abs(x + draggable.clientWidth / scaleFactor - otherX) < snapThreshold)
              x = otherX - draggable.clientWidth / scaleFactor;

            // Snap to top or bottom of the other object
            if (Math.abs(y - (otherY + otherHeight)) < snapThreshold) y = otherY + otherHeight;
            if (Math.abs(y + draggable.clientHeight / scaleFactor - otherY) < snapThreshold)
              y = otherY - draggable.clientHeight / scaleFactor;
          }
        });
      }

      // Constrain draggable within the container boundaries
      x = Math.max(0, Math.min(x, virtualWidth - (draggable.clientWidth / scaleFactor)));
      y = Math.max(0, Math.min(y, virtualHeight - (draggable.clientHeight / scaleFactor)));

      // Apply the position to the draggable
      draggable.style.left = x * scaleFactor + 'px';
      draggable.style.top = y * scaleFactor + 'px';

      dragableXPosition = Math.round(x);
      dragableYPosition = Math.round(y);
    }

    async function stopDrag() {
      document.removeEventListener('mousemove', drag);
      document.removeEventListener('mouseup', stopDrag);
      document.removeEventListener('touchmove', drag);
      document.removeEventListener('touchend', stopDrag);

        // Send position to server
        const response = await fetch(`/api/ui/setpipsmallvideoposition?index=${index}&xPos=${dragableXPosition}&yPos=${dragableYPosition}`, {method: 'POST'});
        if (response.ok) {
            console.log(`API call success => index: ${index} -> new xpos: ${dragableXPosition} | new ypos: ${dragableYPosition}`);
        }
        else
        {
            console.log(`ERROR! HTTP error! status: ${response.status}`);
        }
        /*,
        headers: {
            'Content-Type': 'application/json'
        }
        });*/
    /*
      $.ajax({
        type: "POST",
        url: `/api/ui/setpipsmallvideoposition?index=${index}&xPos=${dragableXPosition}&yPos=${dragableYPosition}`,
        success: function(data) {
          console.log(`index: ${index} -> new xpos: ${dragableXPosition} | new ypos: ${dragableYPosition}`);
        }
      });
      */
    }
  });
};
//#endregion



window.ShowCollapseBootstrapById = async function (fieldSelector, showFlag) {
    new bootstrap.Collapse(`${fieldSelector}`, { show: showFlag });
};



window.AutoScrollAlertBox = async function () {
  const messageBoxes = document.querySelectorAll('.message-box');
  messageBoxes.forEach((messageBox) => {
    const observer = new MutationObserver(() => {
      // Only auto-scroll if user hasn’t manually scrolled up:
      const nearBottom = messageBox.scrollHeight - messageBox.scrollTop - messageBox.clientHeight < 40;
      if (nearBottom) messageBox.scrollTop = messageBox.scrollHeight;
    });

    observer.observe(messageBox, { childList: true, characterData: true, subtree: true });

    // also pin to bottom on load
    messageBox.scrollTop = messageBox.scrollHeight;
  });
};

/* on page rendered/loaded */
window.PageRendered = () => {
    if (isStandaloneGraph) {
        const bitrateChart = document.getElementById('bitrateChart');
        if (bitrateChart) {
            bitrateChart.classList.add('force-show');
        }
    }
};
/** bitrate **/
const DATA_COUNT = 12;

/* CHART */
window.setup = (id,config) => {
    /* source: https://stackoverflow.com/questions/40056555/destroy-chart-js-bar-graph-to-redraw-other-graph-in-same-canvas */
    var ctx = document.getElementById(id).getContext('2d');

    let chartStatus = Chart.getChart(id); // <canvas> id
    if (typeof chartStatus === "undefined") {
        new Chart(ctx, config);
    }
}
window.addData = (id, nameArr, valueArr) => {
    let currentChart = Chart.getChart(id);
    if(typeof currentChart !== "undefined" && typeof currentChart.data.datasets !== "undefined")
    {
        nameArr.forEach(async (item, index) => {
            let val = valueArr[index];
            if(typeof currentChart.data.datasets[index] !== "undefined")
            {
                currentChart.data.datasets[index].label = item;
                if(currentChart.data.datasets[index].data.length >= DATA_COUNT)
                {
                    currentChart.data.datasets[index].data.shift();
                }
                
                if(!Array.isArray(currentChart.data.datasets[index].data))
                {
                    currentChart.data.datasets[index].data = [];
                }
                currentChart.data.datasets[index].data.push(val);
            }
        });
        currentChart.update();
    }
    return true;
}